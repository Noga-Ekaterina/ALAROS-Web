(()=>{var e={};e.id=621,e.ids=[621],e.modules={45869:e=>{"use strict";e.exports=require("next/dist/client/components/static-generation-async-storage.external.js")},20399:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},30517:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},39491:e=>{"use strict";e.exports=require("assert")},6113:e=>{"use strict";e.exports=require("crypto")},82361:e=>{"use strict";e.exports=require("events")},57147:e=>{"use strict";e.exports=require("fs")},13685:e=>{"use strict";e.exports=require("http")},95687:e=>{"use strict";e.exports=require("https")},71017:e=>{"use strict";e.exports=require("path")},12781:e=>{"use strict";e.exports=require("stream")},76224:e=>{"use strict";e.exports=require("tty")},57310:e=>{"use strict";e.exports=require("url")},73837:e=>{"use strict";e.exports=require("util")},59796:e=>{"use strict";e.exports=require("zlib")},26680:()=>{},34382:(e,t,r)=>{"use strict";r.r(t),r.d(t,{originalPathname:()=>y,patchFetch:()=>f,requestAsyncStorage:()=>m,routeModule:()=>d,serverHooks:()=>g,staticGenerationAsyncStorage:()=>h});var s={};r.r(s),r.d(s,{PUT:()=>l});var a=r(49303),o=r(88716),n=r(60670),i=r(87070),u=r(865),c=r(53606);let p=(0,r(57708).unstable_cache)(async()=>{let e=await (0,u.rQ)(`
    query MyQuery {
      projectsPages {
        nominations {
          html
        }
      }
    }
  `);return e&&"string"!=typeof e?(0,c.v)(e.projectsPages[0].nominations.html).map(e=>({id:e.number,title:e.title})):null},["projects-nominations"],{tags:["ProjectsPage"]});async function l(e){try{let t=e.headers.get("Token");if(!t||t!=process.env.PROJECT_NOMINATION_TOKEN)return i.NextResponse.json({error:"token not corect"},{status:401});let r=await e.json();if(!r.data.nomination)return i.NextResponse.json({message:"номинация не указана"},{status:200});let s=await p();if(!s)throw Error("ошибка получения номинаций");let a=null;for(let e of s)if(e.title.trim()==r.data.nomination.replaceAll("\n"," ").replaceAll("^"," ").trim()){a=e.id;break}if(!a)throw Error("в списке номинаций нет такой номинации");if(r.data.nominationId==a)return i.NextResponse.json({message:"id номинации уже установлен"},{status:200});if(!await (0,u.rQ)(`
      mutation {
        updateProject(where: {id: "${r.data.id}"}, data: {nominationId: "${a}"}){
          nominationId
        }
      }
    `))throw Error("ошибка записи id номинации");if(!await (0,u.rQ)(`
      mutation {
        publishProject(where: {id: "${r.data.id}"}, to: PUBLISHED) {
            stage
        }
      }
    `))throw Error("ошибка публикации");return i.NextResponse.json({message:`id номинации установлен: ${a}`},{status:200})}catch(e){return console.error("Error in revalidate route:",e),i.NextResponse.json({error:e instanceof Error?e.message:"ошибка сервера"},{status:500})}}let d=new a.AppRouteRouteModule({definition:{kind:o.x.APP_ROUTE,page:"/api/project-nomination/route",pathname:"/api/project-nomination",filename:"route",bundlePath:"app/api/project-nomination/route"},resolvedPagePath:"C:\\Users\\Пользователь\\Desktop\\work\\alaros\\src\\app\\api\\project-nomination\\route.ts",nextConfigOutput:"",userland:s}),{requestAsyncStorage:m,staticGenerationAsyncStorage:h,serverHooks:g}=d,y="/api/project-nomination/route";function f(){return(0,n.patchFetch)({serverHooks:g,staticGenerationAsyncStorage:h})}},865:(e,t,r)=>{"use strict";r.d(t,{Kb:()=>u,oM:()=>c,rQ:()=>n,sq:()=>i});var s=r(24263),a=r(44760),o=r(57708);let n=async e=>{try{let t=await (0,s.default)({method:"POST",url:"https://ap-south-1.cdn.hygraph.com/content/cm23m5dz501ah07w7g02o9a5n/master",headers:{Authorization:process.env.TOKEN,"cache-control":"no-cache"},data:{query:e}});if(t.data.errors)throw console.error("Hygraph Errors:",t.data.errors),Error("GraphQL request error");return t.data.data}catch(e){if(e instanceof a.d7||e instanceof Error)return e.message;return null}},i=e=>`
            newsAll(orderBy: date_DESC, first: 10, skip: ${10*(e-1)}) {
              date
              cover
              description
              title
              slug
              body { html}
            }
    `,u=(e,t,r)=>{let s=t?`nominationId: "${t}"`:"",a=e?`year: ${e}, `:"",o=e||t?`where: {${a}${s}},`:"";return`
    projectsConnection(
      stage: PUBLISHED,
      ${o}
    ) {
      aggregate {
        count
      }
    }
    projects(
      ${o}
      first: 20, skip: ${20*(r-1)}
      orderBy: year_DESC,
    ){
      name
      nomination
      number
      diploma
      year
      winner
      cover
      images
    }
  `},c=(0,o.unstable_cache)(async()=>{let e=await n(`
          query NewsPageDataQuery {
            newsPages {
              allNews {
                html
              }
              mainTitle
              calendarEventsTitle
              newsTitle
              mainScreenProject {
                cover
                diploma
                signature
                images
                name
                nomination
                number
                winner
                year
              }
            }
          }
      `);return"string"!=typeof e&&e?e.newsPages[0]:e},["news-page-data"],{tags:["NewsPage"]})},5377:(e,t,r)=>{"use strict";r.d(t,{$:()=>s});let s=e=>{let[t]=Array.from(e.matchAll(/<tbody>(.*?)<\/tbody>/gs)).map(e=>e[1]);return Array.from(t.matchAll(/<tr>(.*?)<\/tr>/gs)).map(e=>e[1])}},53606:(e,t,r)=>{"use strict";r.d(t,{v:()=>a});var s=r(5377);let a=e=>(0,s.$)(e).map(e=>{let[t,r,s]=Array.from(e.matchAll(/<td>(?:<p>)?(.*?)(?:<\/p>)?<\/td>/gs)).map(e=>e[1]);return{number:t,title:r,link:s,value:`${t} ${r}`}})}};var t=require("../../../webpack-runtime.js");t.C(e);var r=e=>t(t.s=e),s=t.X(0,[948,708,760,972],()=>r(34382));module.exports=s})();