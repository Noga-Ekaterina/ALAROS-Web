(()=>{var e={};e.id=75,e.ids=[75],e.modules={45869:e=>{"use strict";e.exports=require("next/dist/client/components/static-generation-async-storage.external.js")},20399:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},30517:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},39491:e=>{"use strict";e.exports=require("assert")},6113:e=>{"use strict";e.exports=require("crypto")},82361:e=>{"use strict";e.exports=require("events")},57147:e=>{"use strict";e.exports=require("fs")},13685:e=>{"use strict";e.exports=require("http")},95687:e=>{"use strict";e.exports=require("https")},71017:e=>{"use strict";e.exports=require("path")},12781:e=>{"use strict";e.exports=require("stream")},76224:e=>{"use strict";e.exports=require("tty")},57310:e=>{"use strict";e.exports=require("url")},73837:e=>{"use strict";e.exports=require("util")},59796:e=>{"use strict";e.exports=require("zlib")},26680:()=>{},27023:(e,t,r)=>{"use strict";r.r(t),r.d(t,{originalPathname:()=>w,patchFetch:()=>y,requestAsyncStorage:()=>h,routeModule:()=>m,serverHooks:()=>f,staticGenerationAsyncStorage:()=>g});var s={};r.r(s),r.d(s,{POST:()=>d});var a=r(49303),i=r(88716),o=r(60670),n=r(87070),u=r(57708),c=r(865),p=r(24263);let l=(0,u.unstable_cache)(async()=>{let e=await (0,c.rQ)(`
          query FestivalQuery {
            festivalMains {
              bidTableLink
              diplomaTableLink
              bidNumberProjectColumn
            }
          }`);return"string"!=typeof e&&e?e.festivalMains[0]:e},["forms-link"],{tags:["FestivalMain"]});async function d(e){try{let{recaptcha:t,typeForm:r,...s}=await e.json(),a=await fetch(`https://www.google.com/recaptcha/api/siteverify?secret=${process.env.RECAPTCHA_SECRET_KEY}&response=${t}`,{method:"POST"});if(!(await a.json()).success)throw Error("ошибка капчи");let i=await l();if(!i||"string"==typeof i)throw Error("ошибка получения ссылок");"bid"===r&&(s.bidNumberProjectColumn=i.bidNumberProjectColumn);let o=await p.default.post(i["bid"==r?"bidTableLink":"diplomaTableLink"],s);if("error"==o.data.type)throw Error(`Ошибка сервера: ${o.data.message}`);return n.NextResponse.json({ok:!0})}catch(e){return console.log(e),n.NextResponse.json({ok:!1},{status:400})}}let m=new a.AppRouteRouteModule({definition:{kind:i.x.APP_ROUTE,page:"/api/submit-form/route",pathname:"/api/submit-form",filename:"route",bundlePath:"app/api/submit-form/route"},resolvedPagePath:"C:\\Users\\Пользователь\\Desktop\\work\\alaros\\src\\app\\api\\submit-form\\route.ts",nextConfigOutput:"",userland:s}),{requestAsyncStorage:h,staticGenerationAsyncStorage:g,serverHooks:f}=m,w="/api/submit-form/route";function y(){return(0,o.patchFetch)({serverHooks:f,staticGenerationAsyncStorage:g})}},865:(e,t,r)=>{"use strict";r.d(t,{Kb:()=>u,oM:()=>c,rQ:()=>o,sq:()=>n});var s=r(24263),a=r(44760),i=r(57708);let o=async e=>{try{let t=await (0,s.default)({method:"POST",url:"https://ap-south-1.cdn.hygraph.com/content/cm23m5dz501ah07w7g02o9a5n/master",headers:{Authorization:process.env.TOKEN,"cache-control":"no-cache"},data:{query:e}});if(t.data.errors)throw console.error("Hygraph Errors:",t.data.errors),Error("GraphQL request error");return t.data.data}catch(e){if(e instanceof a.d7||e instanceof Error)return e.message;return null}},n=e=>`
            newsAll(orderBy: date_DESC, first: 10, skip: ${10*(e-1)}) {
              date
              cover
              description
              title
              slug
              body { html}
            }
    `,u=(e,t,r)=>{let s=t?`nominationId: "${t}"`:"",a=e?`year: ${e}, `:"",i=e||t?`where: {${a}${s}},`:"";return`
    projectsConnection(
      stage: PUBLISHED,
      ${i}
    ) {
      aggregate {
        count
      }
    }
    projects(
      ${i}
      first: 20, skip: ${20*(r-1)}
      orderBy: year_DESC,
    ){
      name
      nomination
      number
      diploma
      year
      winner
      cover
      images
    }
  `},c=(0,i.unstable_cache)(async()=>{let e=await o(`
          query NewsPageDataQuery {
            newsPages {
              allNews {
                html
              }
              mainTitle
              calendarEventsTitle
              newsTitle
              mainScreenProject {
                cover
                diploma
                signature
                images
                name
                nomination
                number
                winner
                year
              }
            }
          }
      `);return"string"!=typeof e&&e?e.newsPages[0]:e},["news-page-data"],{tags:["NewsPage"]})}};var t=require("../../../webpack-runtime.js");t.C(e);var r=e=>t(t.s=e),s=t.X(0,[948,708,760,972],()=>r(27023));module.exports=s})();